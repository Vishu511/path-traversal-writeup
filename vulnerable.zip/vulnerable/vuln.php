<?php
if (isset($_GET['file'])) {
    $file = $_GET['file'];
    include("files/" . $file);
} else {
    echo "No file specified.";
}
?>
